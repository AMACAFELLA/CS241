
from product import Product
#Imports from product class in peoduct.py which will be called in this class
class Order :
  #Creates a class called Order with values below.
  def __init__(self) :
    self.id = ""
    self.products = []
    
    
  def get_subtotal(self) :
    #Sum to calulate each product, totals and returns the value
    sub_sum = 0
    for list in self.products:
      sub_sum += list.get_total_price()
    return sub_sum
  
  
  def get_tax(self) :
     #Calutate the tax and returns the value
    tax = (6.5 * self.get_subtotal()) / 100.0
    return tax
  
  
  def get_total(self) :
    #Calulate the total of Subtotal + tax and returns the value
    total = self.get_subtotal() + self.get_tax()
    return total
  
  
  def add_product(self, product) :
    #Appends the product and returns the value
    self.products.append(product)
  
  
  def display_receipt(self) :
    #The display of the output format
    print("Order: {}" .format(self.id))
    for product in self.products:
      product.display()
    print("Subtotal: ${:.2f}" .format(self.get_subtotal()))
    print("Tax: ${:.2f}" .format(self.get_tax()))
    print("Total: ${:.2f}" .format(self.get_total()))
    
    
    
    
    
    
    
    