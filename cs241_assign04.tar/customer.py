
from order import Order

class Customer :
  #Creates class Customer and values are set
  def __init__(self) :
    self.id = ""
    self.name = ""
    self.orders = []
    
    
  def get_order_count(self) :
    #Length is used to count the number of orders and returns the value
    count = len(self.orders)
    return count
  
  
  def get_total(self) :
    #a total varible is created to sum all the total price of all orders and returns the value
    order_total = 0
    for orders in self.orders :
      order_total += orders.get_total()
    return order_total
  
  
  def add_order(self, order) :
    #Appends the order
    self.orders.append(order)
  
  
  def display_summary(self) :
    #Displays the output in the expected format
    print("Summary for customer '{}':" .format(self.id))
    print("Name: {}" .format(self.name))
    print("Orders: {}" .format(self.get_order_count()))
    print("Total: ${:.2f}" .format(self.get_total()))
  
  def display_receipts(self) :
    #Displays the output in the expected format
    print("Detailed receipts for customer '{}':" .format(self.id))
    print("Name: {}" .format(self.name))
    for order in self.orders : 
      print()
      order.display_receipt()
      
    
    
    
    
    
  
  