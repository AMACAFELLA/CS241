#Product class is created
class Product :
  #In the class values are defined and set
  def __init__(self, id, name, price, quantity) :
    self.id = id
    self.name = name
    self.price = price
    self.quantity = quantity
    
  
  def get_total_price(self) :
    # value sum set to multiply the two values to get total price.
    Sum = self.price * self.quantity
    return Sum  
  
  def display(self) :
    #Displays the output in this format.
    print("{} ({}) - ${:.2f}" .format(self.name, self.quantity, self.get_total_price()))
    
    
    
    
    