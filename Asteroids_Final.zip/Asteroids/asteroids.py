"""
File: asteroids.py
Original Author: Br. Burton
Designed to be completed by others
This program implements the asteroids game.
"""
import arcade
import random
import math
from abc import ABC, abstractmethod

"""
Extra! Extra! Read all about it!
The extras include: Intro,main and game over screen.
Story was added to the game.
Music was added to the game. 
Health was added to the game.


"""

# These are Global constants to use throughout the game
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
SCREEN_TITLE = "Asteroids vs Mando/ Angus Macapella"

BULLET_RADIUS = 30
BULLET_SPEED = 10
BULLET_LIFE = 60

SHIP_TURN_AMOUNT = 3
SHIP_THRUST_AMOUNT = 0.25
SHIP_RADIUS = 30

INITIAL_ROCK_COUNT = 5

BIG_ROCK_SPIN = 1
BIG_ROCK_SPEED = 1.5
BIG_ROCK_RADIUS = 15

MEDIUM_ROCK_SPIN = -2
MEDIUM_ROCK_RADIUS = 5

SMALL_ROCK_SPIN = 5
SMALL_ROCK_RADIUS = 2

class Point:
    # set the point of x-coord and y-coord of center
    def __init__(self):
        self.x = 0.0
        self.y = 0.0
        
class Velocity:
    # set the speed of movement with dx and dy
    def __init__(self):
        self.dx = 0
        self.dy = 0

class FlyingObject(ABC):
    """
    Created class FlyingObject with common varibles and an abtract method
    """
    def __init__(self,img):
        self.center = Point()
        self.velocity = Velocity()
        self.alive = True
        self.pic = img
        self.img = arcade.load_texture(self.pic)
        self.width = self.img.width
        self.height = self.img.height
        self.radius = SHIP_RADIUS
        self.angle = 0
        self.speed = 0
        self.direction = 0
        self.alpha = 255
        
        
    
    def advance(self):
        """
        Method for moving flying Objects
        """
        self.wrap()
        self.center.x += self.velocity.dx
        self.center.y += self.velocity.dy
        
        
    def is_alive(self):
        return self.alive
    
    def draw(self):
        """
        Method for drawing flying Objects
        """
        arcade.draw_lrwh_rectangle_textured(self.center.x, self.center.y, self.width, self.height, self.img, self.angle, self.alpha)
    def wrap(self):
        #Wrap method for wrapping the flying object that they stay on the screen
        if self.center.x > SCREEN_WIDTH:
            self.center.x -= SCREEN_WIDTH
        if self.center.x < 0:
            self.center.x += SCREEN_WIDTH
        if self.center.y > SCREEN_HEIGHT:
            self.center.y -= SCREEN_HEIGHT
        if self.center.y < 0:
            self.center.y += SCREEN_WIDTH
            
class Bullet(FlyingObject):
    """
    Created class for bullet inherit from flying object
    """
    def __init__(self,ship_angle,ship_x,ship_y):
        super().__init__("laserBlue01.png")
        self.radius = BULLET_RADIUS
        self.life = BULLET_LIFE
        self.speed = BULLET_SPEED
        self.angle = ship_angle - 90
        self.center.x = ship_x
        self.center.y = ship_y 
        
       
        
    def fire(self):
        #Fire method the position of the bullet is a bit weird for some reason I couldn't get it on the center
        self.velocity.dx -= math.sin(math.radians(self.angle + 90)) * BULLET_SPEED
        self.velocity.dy += math.cos(math.radians(self.angle + 90)) * BULLET_SPEED
    
    def advance(self):
        """
        Method for moving flying Objects
        """
        super().advance()
        self.wrap()
        self.life -= 1
        if(self.life <= 0):
            self.alive = False
        
class Ship(FlyingObject):
    """
    Created class for ship inherit from flying object
    """
    
    def __init__(self):
        super().__init__("playerShip1_orange.png")
        self.angle = 1
        self.center.x = (SCREEN_WIDTH/2)
        self.center.y = (SCREEN_HEIGHT/2)
        self.radius = SHIP_RADIUS
    #For methods for moving the ship 
    def left(self):
        self.angle += SHIP_TURN_AMOUNT
    def right(self):
        self.angle -= SHIP_TURN_AMOUNT
    def thrust(self):
        self.velocity.dx -= math.sin(math.radians(self.angle)) * SHIP_THRUST_AMOUNT
        self.velocity.dy += math.cos(math.radians(self.angle)) * SHIP_THRUST_AMOUNT
    def dn_thrust(self):
        self.velocity.dx += math.sin(math.radians(self.angle)) * SHIP_THRUST_AMOUNT
        self.velocity.dy -= math.cos(math.radians(self.angle)) * SHIP_THRUST_AMOUNT
        
class Asteroid(FlyingObject):
    """
    Created class for asteroid inherit from flying object
    """
    def __init__(self, img):
        super().__init__(img)
        self.radius = 0.0
        
    def hit(self):
        return 4    
        
class SmallRock(Asteroid):
    """
    Created class for SmallRock inherit from Asteroid
    """
    
    def __init__(self):
        super().__init__("meteorGrey_small1.png")
        self.radius = SMALL_ROCK_RADIUS
        self.speed = BIG_ROCK_SPEED
        
    def advance(self):
        super().advance()
        self.angle += SMALL_ROCK_SPIN
        
    def break_Ap(self,asteroids):
        self.alive = False
        
class MediumRock(Asteroid):
    """
    Created class for MediumRock inherit from Asteroid
    """
    def __init__(self):
        super().__init__("meteorGrey_med1.png")
        self.radius = MEDIUM_ROCK_RADIUS
        
        
    def advance(self):
        super().advance()
        self.angle += MEDIUM_ROCK_SPIN
    def break_Ap(self,asteroids):
        
        s = SmallRock()
        s.center.x = self.center.x
        s.center.y = self.center.y
        s.velocity.dy = self.velocity.dy + 1.5
        s.velocity.dy = self.velocity.dx + 1.5
        
        
        s2 = SmallRock()
        s2.center.x = self.center.x
        s2.center.y = self.center.y
        s2.velocity.dy = self.velocity.dy - 1.5
        s2.velocity.dy = self.velocity.dx - 1.5
                
        asteroids.append(s)
        asteroids.append(s2)
        self.alive = False    
class LargeRock(Asteroid):
    """
    Created class for LargeRock inherit from Asteroid
    """
    def __init__(self):
        super().__init__("meteorGrey_big1.png")
        self.center.x = random.randint(1,50)
        self.center.y = random.randint(1,150)
        self.direction = random.randint(1,50)
        self.speed = BIG_ROCK_SPEED
        
        self.radius = BIG_ROCK_RADIUS
        self.velocity.dx = math.cos(math.radians(self.direction)) * self.speed
        self.velocity.dy = math.sin(math.radians(self.direction)) * self.speed
    
    def advance(self):
        super().advance()
        #Rotation of rocks
        self.angle += BIG_ROCK_SPIN
        
    def break_Ap(self,asteroids):
        #Rocks break up into smallar parts
        m = MediumRock()
        m.center.x = self.center.x
        m.center.y = self.center.y
        m.velocity.dy = self.velocity.dy + 2
        
        
        m2 = MediumRock()
        m2.center.x = self.center.x
        m2.center.y = self.center.y
        m2.velocity.dy = self.velocity.dy - 2
        
        s = SmallRock()
        s.center.x = self.center.x
        s.center.y = self.center.y
        s.velocity.dy = self.velocity.dy + 5
        
        
        asteroids.append(m)
        asteroids.append(m2)
        asteroids.append(s)
        self.alive = False
        
    
        
class IntroView(arcade.View):
    """ View to show intro before main screen"""
    #I was not sure if I could inherit the images to save space like we did previuosly since this is an arcade.View I was not sure if I remove and it would still load the screens.
    #Update: I tried to do it but I kept getting errors even when I created a another class to inherit from my IntroView would not load.
    #I'm not sure what the problem could be
    def on_show(self):
        """ Assigns background view """
        self.background2 = None
        self.background2 = arcade.load_texture("tro.png")

    def on_draw(self):
        """ Draws the intro """
        arcade.start_render()
        arcade.draw_lrwh_rectangle_textured(0, 0,SCREEN_WIDTH, SCREEN_HEIGHT,self.background2)

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        """ If the user presses the mouse button, main screen is called. """
        game_main = MainView()
        self.window.show_view(game_main)

class MainView(arcade.View):
    """ View to show main screen """

    def on_show(self):
        """ Assigns background/view """
        self.background3 = None
        self.background3 = arcade.load_texture("main.png")
        
    def on_draw(self):
        """ Draws the background """
        arcade.start_render()
        arcade.draw_lrwh_rectangle_textured(0, 0,SCREEN_WIDTH, SCREEN_HEIGHT,self.background3)

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        """ If the user presses the mouse button, start the game. """
        game_story1 = S1View()
        self.window.show_view(game_story1)

class S1View(arcade.View):
    """ View to show story screen """

    def on_show(self):
        """ Assigns background/view """
        self.background4 = None
        self.background4 = arcade.load_texture("2.png")
        
    def on_draw(self):
        """ Draws the background """
        arcade.start_render()
        arcade.draw_lrwh_rectangle_textured(0, 0,SCREEN_WIDTH, SCREEN_HEIGHT,self.background4)

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        """ If the user presses the mouse button, start the game. """
        game_story2 = S2View()
        self.window.show_view(game_story2)
        
class S2View(arcade.View):
    """ View to show story screen """

    def on_show(self):
        """ Assigns background/view """
        self.background5 = None
        self.background5 = arcade.load_texture("3.png")
        
    def on_draw(self):
        """ Draws the background """
        arcade.start_render()
        arcade.draw_lrwh_rectangle_textured(0, 0,SCREEN_WIDTH, SCREEN_HEIGHT,self.background5)

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        """ If the user presses the mouse button, start the game. """
        game_story3 = S3View()
        self.window.show_view(game_story3)
        
class S3View(arcade.View):
    """ View to show story screen """

    def on_show(self):
        """ Assigns background/view """
        self.background6 = None
        self.background6 = arcade.load_texture("4.png")
        
    def on_draw(self):
        """ Draws the background """
        arcade.start_render()
        arcade.draw_lrwh_rectangle_textured(0, 0,SCREEN_WIDTH, SCREEN_HEIGHT,self.background6)

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        """ If the user presses the mouse button, start the game. """
        game_story4 = S4View()
        self.window.show_view(game_story4)
        
class S4View(arcade.View):
    """ View to show story screen """

    def on_show(self):
        """ Assigns background/view """
        self.background7 = None
        self.background7 = arcade.load_texture("5.png")
        
    def on_draw(self):
        """ Draws the background """
        arcade.start_render()
        arcade.draw_lrwh_rectangle_textured(0, 0,SCREEN_WIDTH, SCREEN_HEIGHT,self.background7)

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        """ If the user presses the mouse button, start the game. """
        game_story5 = S5View()
        self.window.show_view(game_story5)
        
class S5View(arcade.View):
    """ View to show story screen """

    def on_show(self):
        """ Assigns background/view """
        self.background8 = None
        self.background8 = arcade.load_texture("6.png")
        
    def on_draw(self):
        """ Draws the background """
        arcade.start_render()
        arcade.draw_lrwh_rectangle_textured(0, 0,SCREEN_WIDTH, SCREEN_HEIGHT,self.background8)

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        """ If the user presses the mouse button, start the game. """
        game_story6 = S6View()
        self.window.show_view(game_story6)
        
class S6View(arcade.View):
    """ View to show story screen """

    def on_show(self):
        """ Assigns background/view """
        self.background9 = None
        self.background9 = arcade.load_texture("7.png")
        
    def on_draw(self):
        """ Draws the background """
        arcade.start_render()
        arcade.draw_lrwh_rectangle_textured(0, 0,SCREEN_WIDTH, SCREEN_HEIGHT,self.background9)

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        """ If the user presses the mouse button, start the game. """
        game_story7 = S7View()
        self.window.show_view(game_story7)
        
class S7View(arcade.View):
    """ View to show story screen """

    def on_show(self):
        """ Assigns background/view """
        self.background10 = None
        self.background10 = arcade.load_texture("8.png")
        
    def on_draw(self):
        """ Draws the background """
        arcade.start_render()
        arcade.draw_lrwh_rectangle_textured(0, 0,SCREEN_WIDTH, SCREEN_HEIGHT,self.background10)

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        """ If the user presses the mouse button, start the game. """
        game_story8 = S8View()
        self.window.show_view(game_story8)
        
class S8View(arcade.View):
    """ View to show last story screen """

    def on_show(self):
        """ Assigns background/view """
        self.background11 = None
        self.background11 = arcade.load_texture("9.png")
        
    def on_draw(self):
        """ Draws the background """
        arcade.start_render()
        arcade.draw_lrwh_rectangle_textured(0, 0,SCREEN_WIDTH, SCREEN_HEIGHT,self.background11)

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        """ If the user presses the mouse button, start the game. """
        game_view = GameView()
        game_view.setup()
        self.window.show_view(game_view)
        
class Over1View(arcade.View):
    """ View to show Over after destorying the asteroids screen """

    def on_show(self):
        """ Assigns background/view """
        self.background12 = None
        self.background12 = arcade.load_texture("last.png")
        self.play = False
        
    def on_draw(self):
        """ Draws the background """
        arcade.start_render()
        arcade.draw_lrwh_rectangle_textured(0, 0,SCREEN_WIDTH, SCREEN_HEIGHT,self.background12)

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        """ If the user presses the mouse button, start the game. """
        game_view1 = GameView()
        game_view1.setup()
        self.window.show_view(game_view1)

class Over2View(arcade.View):
    """ View to show Game Over after health hit zero screen """

    def on_show(self):
        """ Assigns background/view """
        self.background13 = None
        self.background13 = arcade.load_texture("over2.png")
        self.play = False
        
    def on_draw(self):
        """ Draws the background """
        arcade.start_render()
        arcade.draw_lrwh_rectangle_textured(0, 0,SCREEN_WIDTH, SCREEN_HEIGHT,self.background13)

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        """ If the user presses the mouse button, start the game. """
        game_view2 = GameView()
        game_view2.setup()
        self.window.show_view(game_view2)

class GameView(arcade.View):
    """
    This class handles all the game callbacks and interaction
    This class will then call the appropriate functions of
    each of the above classes.
    You are welcome to modify anything in this class.
    """

    def __init__(self):
        """
        Sets up the initial conditions of the game
        :param width: Screen width
        :param height: Screen height
        """
        super().__init__()
        #Added a new background and music
        self.background = None
        self.sound_song = arcade.load_sound("mando.mp3")
        #Although it overloops when called again. I tried to figure this out without having to add the player function but it was not possible.
        #Example the stop sound needed to have the player fuction.
        self.play = arcade.play_sound(self.sound_song)
        self.sound_fire = arcade.load_sound("laser.ogg")
        arcade.set_background_color(arcade.color.SMOKY_BLACK)

        self.held_keys = set()
        #Creates a list for the asteroids
        self.asteroids = []
        self.bullets = []
        self.health = 20
        #Starts game with 5 large rock asteroids
        for i in range(INITIAL_ROCK_COUNT):
            lr = LargeRock()
            self.asteroids.append(lr)
            
        self.ship = Ship()
        

        # TODO: declare anything here you need the game class to track
    def setup(self):
        """ Set up the game and initialize the variables. """

        # Loads the background ans music
        self.background = arcade.load_texture("space.png")
        
        self.play = True
        
        
            
    def on_draw(self):
        """
        Called automatically by the arcade framework.
        Handles the responsibility of drawing all elements.
        """

        # clear the screen to begin drawing
        arcade.start_render()
        # TODO: draw each object
        # Draw the background texture
        arcade.draw_lrwh_rectangle_textured(0, 0,SCREEN_WIDTH, SCREEN_HEIGHT,self.background)
        # Drawing the flying objects
        for asteroid in self.asteroids:
            asteroid.draw()
        for bullet in self.bullets:
            bullet.draw()
         
        self.ship.draw()
        self.draw_health()
        
    
    def draw_health(self):
        """
        Puts the current health on the screen
        """
        health_text = "Health: {}".format(self.health)
        start_x = 10
        start_y = SCREEN_HEIGHT - 20
        arcade.draw_text(health_text, start_x=start_x, start_y=start_y, font_size=15, color=arcade.color.RED)
    
    def remove_notAliveObjects(self):
        #Removes the objects not alive
        
        for bullet in self.bullets:
            if not bullet.alive:
                self.bullets.remove(bullet)
                
        for asteroid in self.asteroids:
            if not asteroid.alive:
                self.asteroids.remove(asteroid)
                
    def check_collisions(self):
        #Checks to see if objects collide with eachother. In this case bullets with asteroids
        for bullet in self.bullets:
            for asteroid in self.asteroids:
                #Fixed the bullet collision
                if ((bullet.alive) and (asteroid.alive)):
                    dis_max = bullet.radius + asteroid.radius
                    dx = abs(bullet.center.x - asteroid.center.x)
                    dy = abs(bullet.center.y - asteroid.center.y)

                    if  (dx < dis_max) and (dy < dis_max):
                        asteroid.break_Ap(self.asteroids)
                        bullet.alive = False
                        asteroid.alive = False
        #Checks to see if ship hits asteroids                
        for asteroid in self.asteroids:
            if ((self.ship.alive) and (asteroid.alive)):
                dx = abs(asteroid.center.x - self.ship.center.x)
                dy = abs(asteroid.center.y - self.ship.center.y)
                dis_max = asteroid.radius + self.ship.radius
                if((dx < dis_max) or (dy < dis_max)):
                    #When asteroid hits shipm ship takes damage. This will make the game harder and fun to play.
                    #When asteroids hit ship they deal damage and it get's destroyed.
                    asteroid.alive = False
                    self.health -= asteroid.hit()
                    if(self.health <= 0):
                        self.play = None
                        view = Over2View()
                        self.window.show_view(view)
                                          
    def update(self, delta_time):
        """
        Update each object in the game.
        :param delta_time: tells us how much time has actually elapsed
        """
        self.check_keys()
        #Asteroids are moving
        for asteroid in self.asteroids:
            asteroid.advance()
        #Bullets are firing  
        for bullet in self.bullets:
            bullet.advance()
        #Not alive objects are removed
        self.remove_notAliveObjects()
        #Ckecks for hits bullet/Asteroids
        self.check_collisions()
                   
        self.ship.advance()
        # TODO: Tell everything to advance or move forward one step in time.

        # TODO: Check for collisions
        #When asteriods there are no more asteroids display game over.
        if len(self.asteroids) == 0:
            self.play = None
            view = Over1View()
            self.window.show_view(view)
            

    def check_keys(self):
        """
        This function checks for keys that are being held down.
        You will need to put your own method calls in here.
        """
        #Moving the ship when key is pressed
        if arcade.key.LEFT in self.held_keys:
            self.ship.left()

        if arcade.key.RIGHT in self.held_keys:
            self.ship.right()

        if arcade.key.UP in self.held_keys:
            self.ship.thrust()
            #Speed Cap for thrust up
            if self.ship.velocity.dx > 3:
                self.ship.velocity.dx = 3
            if self.ship.velocity.dx < -3:
                self.ship.velocity.dx = -3
            if self.ship.velocity.dy > 3:
                self.ship.velocity.dy = 3
            if self.ship.velocity.dy < -3:
                self.ship.velocity.dy = -3
                                            
        if arcade.key.DOWN in self.held_keys:
            #Speed cap for down thrust half of up thrust
            self.ship.dn_thrust()
            if self.ship.velocity.dx > 4:
                self.ship.velocity.dx = 4
            if self.ship.velocity.dx < -4:
                self.ship.velocity.dx = -4
            if self.ship.velocity.dy > 4:
                self.ship.velocity.dy = 4
            if self.ship.velocity.dy < -4:
                self.ship.velocity.dy = -4

    def on_key_press(self, key: int, modifiers: int):
        """
        Puts the current key in the set of keys that are being held.
        You will need to add things here to handle firing the bullet.
        """
        if self.ship.alive:
            self.held_keys.add(key)

            if key == arcade.key.SPACE:
                # TODO: Fire the bullet here!
                #Key is pressed bullets fire
                arcade.play_sound(self.sound_fire)
                bullet = Bullet(self.ship.angle, self.ship.center.x, self.ship.center.y)
                self.bullets.append(bullet)
                bullet.fire()
                

    def on_key_release(self, key: int, modifiers: int):
        """
        Removes the current key from the set of held keys.
        """
        if key in self.held_keys:
            self.held_keys.remove(key)
            
# Creates the game and starts it going
def main():
    """ Main method """

    window = arcade.Window(SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_TITLE)
    start_view = IntroView()
    window.show_view(start_view)
    arcade.run()


if __name__ == "__main__":
    main()