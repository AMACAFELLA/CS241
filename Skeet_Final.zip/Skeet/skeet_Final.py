import random
import arcade
import math
import os

SCREEN_WIDTH = 600
SCREEN_HEIGHT = 500
SCREEN_TITLE = "Pokemon Gun/ Angus Macapella"


RIFLE_WIDTH = 100
RIFLE_HEIGHT = 20
#RIFLE_COLOR = arcade.color.RED

BULLET_RADIUS = 3
#New radius for the bullet looks more natural bigger
BULLET_NEW = 20
BULLET_COLOR = arcade.color.BLACK
BULLET_SPEED = 10

TARGET_RADIUS = 20
#New radius for sprite
NEW_RADIUS = 70
TARGET_COLOR = arcade.color.ORANGE
TARGET_SAFE_COLOR = arcade.color.LIGHT_BLUE
TARGET_SAFE_RADIUS = 15


STANDARD_POINT = 1
STRONG_POINT= 7
SAFE_POINT = -10
STRONG_LIVES = 3


class Point:
    # set the point of x-coord and y-coord of center
    def __init__(self):
        self.x = 0.0
        self.y = 0.0
        
class Velocity:
    # set the speed of movement with dx and dy
    def __init__(self):
        self.dx = 0.0
        self.dy = 0.0

class Rifle:
    """
    The rifle is a rectangle that tracks the mouse.
    """
    def __init__(self):
        self.center = Point()
        self.center.x = 0
        self.center.y = 0
        self.angle = 45
        self.shotgun = None
        

    def draw(self):
        self.shotgun = arcade.load_texture("shotgun.png")
        #Below low was the draw rectangle for the rifle
        #arcade.draw_rectangle_filled(self.center.x, self.center.y, RIFLE_WIDTH, RIFLE_HEIGHT, RIFLE_COLOR, 360-self.angle)
        arcade.draw_lrwh_rectangle_textured(self.center.x, self.center.y, RIFLE_WIDTH, RIFLE_HEIGHT,self.shotgun, self.angle)
        

class FlyingObject:
    """
    Created class FlyingObject with common varibles
    """
    def __init__(self):
        self.center = Point()
        self.velocity = Velocity()
        self.radius = 0.0
        self.alive = True
    """    
    Pass the draw function   
    """
    def draw(self):
        pass
        
    def advance(self):
        """
        Method for moving flying Objects
        """
        self.center.x += self.velocity.dx
        self.center.y += self.velocity.dy
        
    def is_off_screen(self, screen_width, screen_height):
        """
        Method to see if the flying objects are off the screen
        """
        if (self.center.x > screen_width  or self.center.y > screen_height):
            return True
        else:
            return False
    
        
class Bullet(FlyingObject):
    """
    Class for bullet inherent from flying object
    """
    def __init__(self):
        super().__init__()
        #Variable for the bullet without the sprite. I made a new radius to see the bullet better.
        self.radius = BULLET_RADIUS
        self.color = BULLET_COLOR
        self.bullet = None
        
        # Sounds: When mouse is press the shotgun sound plays
        self.bullet_sound = arcade.load_sound("Shotgun_Sound.mp3")
        
        
    def draw(self):
        #The sprite for the bullet and draw added with the new radius defined as BULLET_NEW to make it look bigger
        self.bullet = arcade.load_texture("bullet.png")
        arcade.draw_lrwh_rectangle_textured(self.center.x, self.center.y,BULLET_NEW, BULLET_NEW, self.bullet)
        #arcade.draw_circle_filled(self.center.x, self.center.y, self.radius, self.color)
        
    
    def fire(self, angle):
        """
        Method to get the perfect shot that follows the angle of the mouse
        """
        self.velocity.dx = math.cos(math.radians(angle)) * BULLET_SPEED
        self.velocity.dy = math.sin(math.radians(angle)) * BULLET_SPEED
        
class Target(FlyingObject):
    """
    Target class inherit from flying object
    """
    def __init__(self):
        """
        Assigning values to make targets fly randomaly across the screen
        """
        super().__init__()
        self.center.y = random.uniform(SCREEN_HEIGHT/2, SCREEN_HEIGHT)
        self.velocity.dx = random.uniform(1,5)
        self.velocity.dy = random.uniform(-2,2)
        #Radius for target was changed to fit the sprite
        self.radius = TARGET_RADIUS
        #Color is no longer needed
        self.color = TARGET_COLOR
        self.point = 0
        self.type = "unknown"


    def draw(self):
        pass    
   
    def hit(self):
        self.alive = False
        return 1


class Standard(Target):
    
    """
    Class for the standard target type inherit from target
    """
    def __init__(self):
        super().__init__()
        self.type = "Standard"
        self.point = STANDARD_POINT
        self.bird1 = None
        
    def draw(self):
        #Assigning sprite to target standard and drawing the sprite with the new radius defined as NEW_RADIUS
        self.bird1 = arcade.load_texture("bird1.png")
        arcade.draw_lrwh_rectangle_textured(self.center.x, self.center.y,NEW_RADIUS,NEW_RADIUS, self.bird1)
        #arcade.draw_circle_filled(self.center.x, self.center.y, self.radius, self.color)
       
    def hit(self):
        """
        Method to hit the target and increase points by 1 than remove object
        """
        self.alive = False
        return self.point

class Strong(Target):
    
    """
    Class for strong target inherit from target
    """
    def __init__(self):
        super().__init__()
        self.velocity.dx = random.uniform(1,3)
        self.velocity.dy = random.uniform(-2,2)
        self.type = "Strong"
        #Plays sound whenever a target is hit
        self.strong_sound = arcade.load_sound("Target.mp3")
        # Total point of strong target is 7 points
        self.point = STRONG_POINT
        # Set 3 hits to destroy this target        
        self.lives = STRONG_LIVES
        
    def draw(self):
        """
        Method for the number inside the circle
        """
        arcade.draw_circle_outline(self.center.x, self.center.y, self.radius, self.color)
        text_x = self.center.x - (self.radius / 2)
        text_y = self.center.y - (self.radius / 2)
        arcade.draw_text(repr(self.lives), text_x, text_y, TARGET_COLOR, font_size=20)
       
    def hit(self):
        """
        Method to calulate 1 point = 2 hits, 5 points to gryfindor on the third hit.
        """
        self.lives -= 1
        if self.lives > 0:
            self.alive = True
            self.point = 1
            return self.point
        else:
            self.alive = False
            self.point = 5
            return self.point

class Safe(Target):
    
    """
    Class for the safe inherit from target
    """
    def __init__(self):
        super().__init__()
        #Color and Radius is not needed for the sprite
        #self.color = TARGET_SAFE_COLOR
        #self.radius = TARGET_SAFE_RADIUS
        self.type = "Safe"
        self.bird2 = None

        
    def draw(self):
        """
        Method for drawing a square
        """
        #Sprite replaces the drawn rectangle and drawn with new radius as defined as NEW_RADIUS
        self.bird2 = arcade.load_texture("bird2.png")
        arcade.draw_lrwh_rectangle_textured(self.center.x, self.center.y,NEW_RADIUS,NEW_RADIUS, self.bird2)
        #arcade.draw_rectangle_filled(self.center.x, self.center.y, self.radius, self.radius, self.color)
       
    def hit(self):
        """
        Method to minus 10 points when destoryed
        """
        self.point = SAFE_POINT        
        self.alive = False
        return self.point

class IntroView(arcade.View):
    """ View to show intro before main screen """

    def on_show(self):
        """ Assigns background view """
        
        
        self.background2 = None
        
        self.background2 = arcade.load_texture("intro.png")

    def on_draw(self):
        """ Draws the intro """
        arcade.start_render()
        arcade.draw_lrwh_rectangle_textured(0, 0,SCREEN_WIDTH, SCREEN_HEIGHT,self.background2)

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        """ If the user presses the mouse button, main screen is called. """
        game_main = MainView()
        self.window.show_view(game_main)
        
class MainView(arcade.View):
    """ View to show main screen """

    def on_show(self):
        """ Assigns background/view """
        self.background3 = None
        self.background3 = arcade.load_texture("menu.png")
        
    def on_draw(self):
        """ Draws the background """
        arcade.start_render()
        arcade.draw_lrwh_rectangle_textured(0, 0,SCREEN_WIDTH, SCREEN_HEIGHT,self.background3)

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        """ If the user presses the mouse button, start the game. """
        game_view = GameView()
        game_view.setup()
        self.window.show_view(game_view)

class GameView(arcade.View):
    """
    Had to change the game to arcade.View to get the intro and main screen working
    
    This class handles all the game callbacks and interaction
    It assumes the following classes exist:
        Rifle
        Target (and it's sub-classes)
        Point
        Velocity
        Bullet

    This class will then call the appropriate functions of
    each of the above classes.

    You are welcome to modify anything in this class, but mostly
    you shouldn't have to. There are a few sections that you
    must add code to.
    """

    def __init__(self):
        """
        Sets up the initial conditions of the game
        :param width: Screen width
        :param height: Screen height
        
        This was changed due to arcade.View but the super handles the width and height as well as it's assigned in the main function.
        """
        super().__init__()
        #This is the file path so everything in this folder can be accessed 
        file_path = os.path.dirname(os.path.abspath(__file__))
        os.chdir(file_path)

        self.rifle = Rifle()
        self.target = Target()
        self.score = 0

        self.bullets = []
        self.targets = []
        
        # TODO: Create a list for your targets (similar to the above bullets)
        # Background image will be stored in this variable
        self.background = None
        arcade.set_background_color(arcade.color.AMAZON)
        self.sound_song = arcade.load_sound("pokemon.mp3")
        
        
        
    
    def setup(self):
        """ Set up the game and initialize the variables. """

        # Loads the background 
        
        self.background = arcade.load_texture("background.jpg")
        arcade.play_sound(self.sound_song)
        
    
    def on_draw(self):
        """
        Called automatically by the arcade framework.
        Handles the responsibility of drawing all elements.
        """

        # clear the screen to begin drawing
        arcade.start_render()
        
        # Draw the background texture
        arcade.draw_lrwh_rectangle_textured(0, 0,SCREEN_WIDTH, SCREEN_HEIGHT,self.background)
        
       

        # draw each object
        self.rifle.draw()
        

        for bullet in self.bullets:
            bullet.draw()

        # TODO: iterate through your targets and draw them...
        
        for target in self.targets:
            target.draw()


        self.draw_score()
        

    def draw_score(self):
        """
        Puts the current score on the screen
        """
        score_text = "Score: {}".format(self.score)
        start_x = 10
        start_y = SCREEN_HEIGHT - 20
        arcade.draw_text(score_text, start_x=start_x, start_y=start_y, font_size=15, color=arcade.color.RED)

    def update(self, delta_time):
        """
        Update each object in the game.
        :param delta_time: tells us how much time has actually elapsed
        """
        self.check_collisions()
        self.check_off_screen()

        # decide if we should start a target
        if random.randint(1, 50) == 1:
            self.create_target()

        for bullet in self.bullets:
            bullet.advance()
            
        for target in self.targets:
            target.advance()

        # TODO: Iterate through your targets and tell them to advance

    def create_target(self):
        """
        Creates a new target of a random type and adds it to the list.
        :return:
        """
        if random.randint(1, 4) == 1:
            target = Standard()
            self.targets.append(target)
        
        elif random.randint(1, 4) == 2:
            target = Strong()
            self.targets.append(target)
            
        elif random.randint(1, 4) == 3:
            target = Safe()
            self.targets.append(target)
            
        #TODO: Decide what type of target to create and append it to the list

    def check_collisions(self):
        """
        Checks to see if bullets have hit targets.
        Updates scores and removes dead items.
        :return:
        """

        # NOTE: This assumes you named your targets list "targets"

        for bullet in self.bullets:
            for target in self.targets:

                # Make sure they are both alive before checking for a collision
                if bullet.alive and target.alive:
                    too_close = bullet.radius + target.radius

                    if (abs(bullet.center.x - target.center.x) < too_close and
                                abs(bullet.center.y - target.center.y) < too_close):
                        # its a hit!
                        bullet.alive = False
                        self.score += target.hit()
                        arcade.play_sound(Strong().strong_sound)

                        # We will wait to remove the dead objects until after we
                        # finish going through the list

        # Now, check for anything that is dead, and remove it
        self.cleanup_zombies()

    def cleanup_zombies(self):
        """
        Removes any dead bullets or targets from the list.
        :return:
        """
        for bullet in self.bullets:
            if not bullet.alive:
                self.bullets.remove(bullet)

        for target in self.targets:
            if not target.alive:
                self.targets.remove(target)

    def check_off_screen(self):
        """
        Checks to see if bullets or targets have left the screen
        and if so, removes them from their lists.
        :return:
        """
        for bullet in self.bullets:
            if bullet.is_off_screen(SCREEN_WIDTH, SCREEN_HEIGHT):
                self.bullets.remove(bullet)

        for target in self.targets:
            if target.is_off_screen(SCREEN_WIDTH, SCREEN_HEIGHT):
                self.targets.remove(target)

    def on_mouse_motion(self, x: float, y: float, dx: float, dy: float):
        # set the rifle angle in degrees
        self.rifle.angle = self._get_angle_degrees(x, y)

    def on_mouse_press(self, x: float, y: float, button: int, modifiers: int):
        
        angle = self._get_angle_degrees(x, y)

        bullet = Bullet()
        bullet.fire(angle)

        self.bullets.append(bullet)
        arcade.play_sound(bullet.bullet_sound)

    def _get_angle_degrees(self, x, y):
        """
        Gets the value of an angle (in degrees) defined
        by the provided x and y.

        Note: This could be a static method, but we haven't
        discussed them yet...
        """
        # get the angle in radians
        angle_radians = math.atan2(y, x)

        # convert to degrees
        angle_degrees = math.degrees(angle_radians)

        return angle_degrees
    
def main():
    """ Main method """

    window = arcade.Window(SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_TITLE)
    start_view = IntroView()
    window.show_view(start_view)
    arcade.run()


if __name__ == "__main__":
    main()
